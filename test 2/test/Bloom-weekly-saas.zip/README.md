# Highlights

- Used a combination of Flex and Bootstrap 
- Responsive in various browser sizes, including iPad and Mobile sizes
- Created circle graph using CSS
